
<FORM NAME="formName" ACTION="txt2jpeg.php" METHOD=POST target="imagebox">
<h3>Turn text into an image (Jpeg) dynamically</h3>
<a href="http://www.phpdevshed.com/">Visit phpDevShed.com/forum/</a><br>
<!-- by michael@phpdevshed.com -->
image width <INPUT TYPE="text" NAME="imwidth" SIZE=3 MAXLENGTH=3> and height <INPUT TYPE="text" NAME="imheight" SIZE=3 MAXLENGTH=3> in (pixels) now go <INPUT TYPE="submit" NAME="submitName" VALUE="generate image">
<br><TEXTAREA NAME="mytext" ROWS="5" COLS="60" WRAP="physical"></TEXTAREA>
<br>
To create a new line - hit your return key - try to keep<br>
the each line of your text from wrapping. - What can you do with this?
</FORM>
